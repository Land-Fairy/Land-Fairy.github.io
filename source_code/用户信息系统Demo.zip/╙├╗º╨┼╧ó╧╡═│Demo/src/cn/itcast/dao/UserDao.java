package cn.itcast.dao;

import cn.itcast.domain.User;

import java.util.List;
import java.util.Map;

/**
 * 用户操作的DAO
 */
public interface UserDao {
    /* 查询所有用户信息 */
    public List<User> findAll();
    /* 根据用户名+密码查询 ==》 login 判断用户是否存在 */
    User findUserByUsernameAndPassword(String username, String password);
    /* 添加用户信息 */
    void add(User user);
    /* 删除用户信息 */
    void delete(int id);
    /* 根据UserId 查询 User*/
    User findById(int i);
    /* 更新 User信息*/
    void update(User user);
    /* 查询总记录数 */
    int findTotalCount(Map<String, String[]> condition);
    /**分页查询每页记录*/
    List<User> findByPage(int start, int rows, Map<String, String[]> condition);
}
